package com.urs.pifdamesa;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Ponte chamada pela página (window.PifAndroid): salva a imagem da partida na
 * galeria, envia a imagem para outros apps e salva o backup em Downloads.
 */
public class ImageBridge {
    private final Activity activity;

    public ImageBridge(Activity activity) {
        this.activity = activity;
    }

    private static String safeName(String fileName, String fallback) {
        return fileName == null || fileName.isEmpty() ? fallback : fileName.replaceAll("[^A-Za-z0-9._-]", "-");
    }

    private void toast(String text) {
        activity.runOnUiThread(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show());
    }

    /** Grava a imagem na galeria (Pictures/PifDaMesa) e devolve o endereço dela, ou null. */
    private Uri writeImage(String base64Png, String fileName) throws Exception {
        byte[] bytes = Base64.decode(base64Png, Base64.DEFAULT);
        String name = safeName(fileName, "pif-da-mesa.png");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PifDaMesa");
            ContentResolver resolver = activity.getContentResolver();
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) return null;
                out.write(bytes);
            }
            return uri;
        }
        File dir = new File(activity.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PifDaMesa");
        if (!dir.exists() && !dir.mkdirs()) return null;
        File file = new File(dir, name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(bytes);
        }
        return Uri.fromFile(file);
    }

    /** Liga ou desliga a opção de manter a tela acesa enquanto o app está aberto. */
    @JavascriptInterface
    public void setKeepScreenOn(boolean on) {
        activity.runOnUiThread(() -> {
            if (on) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    @JavascriptInterface
    public boolean saveImage(String base64Png, String fileName) {
        try {
            if (writeImage(base64Png, fileName) == null) return false;
            toast("Imagem salva na galeria (PifDaMesa)");
            return true;
        } catch (Exception error) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean shareImage(String base64Png, String fileName) {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            Uri uri = writeImage(base64Png, fileName);
            if (uri == null) return false;
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Enviar resultado da mesa");
            activity.runOnUiThread(() -> activity.startActivity(chooser));
            return true;
        } catch (Exception error) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean saveText(String text, String fileName) {
        try {
            byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
            String name = safeName(fileName, "pif-da-mesa-backup.json");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, name);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                ContentResolver resolver = activity.getContentResolver();
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) return false;
                    out.write(bytes);
                }
            } else {
                File dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null || (!dir.exists() && !dir.mkdirs())) return false;
                try (FileOutputStream out = new FileOutputStream(new File(dir, name))) {
                    out.write(bytes);
                }
            }
            toast("Backup salvo em Downloads");
            return true;
        } catch (Exception error) {
            return false;
        }
    }
}
