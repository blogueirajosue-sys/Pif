// Layout "Mesa": os jogadores sentados em volta de uma mesa de feltro, com o pote no meio.
import type { Room } from './lib/roomApi'
import { formatMoney, initialsOf, playerColor } from './lib/format'

type Seat = { id: string; name: string; balance: number; status: string; tone: 'turn' | 'in' | 'out' | 'idle'; opener: boolean; doubled: boolean; me: boolean }

function seatStatus(room: Room, id: string): Pick<Seat, 'status' | 'tone' | 'opener' | 'doubled'> {
  const hand = room.activeRound
  const opener = (hand ? hand.firstPlayerId : room.nextOpenerId) === id
  if (!hand) return { status: opener ? 'abre a próxima' : '', tone: 'idle', opener, doubled: false }
  const doubled = hand.doubledByPlayerIds.includes(id)
  const response = hand.responses?.[id]
  if (!hand.playerIds.includes(id) && !hand.foldedPlayerIds.includes(id)) return { status: 'fora da mão', tone: 'out', opener, doubled }
  if (hand.phase === 'announcing') return opener ? { status: 'anunciando...', tone: 'turn', opener, doubled } : { status: 'esperando', tone: 'idle', opener, doubled }
  if (hand.phase === 'responding') {
    if (response === 'fold') return { status: 'saiu', tone: 'out', opener, doubled }
    if (response === 'pending') return { status: 'decidindo...', tone: 'turn', opener, doubled }
    return { status: doubled ? 'dobrou' : opener ? 'abriu' : 'vai jogar', tone: 'in', opener, doubled }
  }
  if (hand.phase === 'playing') {
    if (hand.foldedPlayerIds.includes(id)) return { status: 'saiu', tone: 'out', opener, doubled }
    return { status: doubled ? 'dobrou' : 'jogando', tone: 'in', opener, doubled }
  }
  return { status: 'conferindo', tone: 'idle', opener, doubled }
}

export function TableView({ room, playerId, balances }: { room: Room; playerId: string; balances: Map<string, number> }) {
  const active = room.players.filter((player) => player.inGame)
  // Quem está vendo fica sentado embaixo; os outros seguem a ordem da mesa.
  const start = Math.max(0, active.findIndex((player) => player.id === playerId))
  const ordered = [...active.slice(start), ...active.slice(0, start)]
  const seats: Seat[] = ordered.map((player) => ({
    id: player.id,
    name: player.name,
    balance: balances.get(player.id) ?? 0,
    me: player.id === playerId,
    ...seatStatus(room, player.id),
  }))
  const hand = room.activeRound
  const inHand = hand ? hand.playerIds.filter((id) => hand.responses?.[id] !== 'fold').length : 0
  const pot = hand?.value ? hand.value * inHand : 0
  const phase = !hand
    ? room.status === 'finished' ? 'Mesa encerrada' : 'Entre rodadas'
    : hand.phase === 'announcing' ? 'Esperando o anúncio'
      : hand.phase === 'responding' ? 'Quem vai jogar?'
        : hand.phase === 'playing' ? 'Cartas na mesa' : 'Distribuindo'
  const count = seats.length

  return <div className="felt-stage" aria-label="Mesa de jogo">
    <div className="felt-table">
      <div className="felt-center">
        <span className="felt-round">{hand ? `Mão ${hand.number}` : `${room.rounds.length} ${room.rounds.length === 1 ? 'rodada' : 'rodadas'}`}</span>
        {pot > 0
          ? <><span className="felt-chips" aria-hidden="true"><i /><i /><i /></span><strong className="felt-pot">{formatMoney(pot)}</strong><span className="felt-sub">{formatMoney(hand!.value!)} por jogador</span></>
          : <strong className="felt-pot felt-pot-idle">♠</strong>}
        <span className="felt-phase">{phase}</span>
      </div>
    </div>
    {seats.map((seat, index) => {
      // Distribui os lugares numa elipse, começando embaixo (quem está vendo).
      const angle = Math.PI / 2 + (2 * Math.PI * index) / count
      const left = 50 + 41 * Math.cos(angle)
      const top = 50 + 38 * Math.sin(angle)
      return <div className={`felt-seat seat-${seat.tone} ${seat.me ? 'seat-me' : ''}`} key={seat.id} style={{ left: `${left}%`, top: `${top}%` }}>
        <span className={`avatar avatar-${playerColor(seat.id)} felt-avatar`}>{initialsOf(seat.name)}
          {seat.opener && <b className="seat-badge" title="Abre a mão">A</b>}
          {seat.doubled && <b className="seat-badge seat-badge-double" title="Dobrou">2x</b>}
        </span>
        <span className="seat-name">{seat.me ? 'Você' : seat.name}</span>
        <span className={`seat-balance ${seat.balance > 0.004 ? 'positive' : seat.balance < -0.004 ? 'negative' : ''}`}>{seat.balance > 0.004 ? '+' : ''}{formatMoney(seat.balance)}</span>
        {seat.status && <span className="seat-status">{seat.status}</span>}
      </div>
    })}
  </div>
}
