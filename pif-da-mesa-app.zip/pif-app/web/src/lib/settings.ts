// Configurações da mesa (guardadas no celular do anfitrião) e preferências deste aparelho.
import { useEffect, useState } from 'react'
import { buildSummary } from './engine'
import type { Room } from './roomApi'

export type Settings = {
  /** Valor que já vem preenchido no anúncio. null = desligado. */
  defaultValue: number | null
  /** Mostrar a chave Pix de quem recebe no fechamento. */
  pixEnabled: boolean
  /** Chaves Pix por nome (nome em minúsculas). */
  pix: Record<string, string>
  /** Botão de enviar a imagem da noite direto (WhatsApp etc.). */
  shareImageEnabled: boolean
  /** Aba de estatísticas no histórico geral. */
  statsEnabled: boolean
}

export const defaultSettings: Settings = { defaultValue: null, pixEnabled: false, pix: {}, shareImageEnabled: false, statsEnabled: false }

export const nameKey = (name: string) => name.trim().toLocaleLowerCase('pt-BR')

let current: Settings = defaultSettings
const listeners = new Set<(settings: Settings) => void>()
let loading: Promise<void> | null = null

function normalize(raw: unknown): Settings {
  const data = (raw && typeof raw === 'object' ? raw : {}) as Partial<Settings>
  const value = Number(data.defaultValue)
  return {
    defaultValue: data.defaultValue !== null && Number.isFinite(value) && value > 0 ? value : null,
    pixEnabled: Boolean(data.pixEnabled),
    pix: data.pix && typeof data.pix === 'object' ? Object.fromEntries(Object.entries(data.pix).filter(([, key]) => typeof key === 'string' && key.trim())) : {},
    shareImageEnabled: Boolean(data.shareImageEnabled),
    statsEnabled: Boolean(data.statsEnabled),
  }
}

async function load() {
  try {
    const response = await fetch('/api/settings')
    if (response.ok) {
      current = normalize(await response.json())
      listeners.forEach((listener) => listener(current))
    }
  } catch {
    // mantém o que já tinha
  }
}

export function useSettings(): Settings {
  const [settings, setSettings] = useState(current)
  useEffect(() => {
    listeners.add(setSettings)
    loading ??= load().finally(() => { loading = null })
    const timer = window.setInterval(() => { void load() }, 20000)
    return () => { listeners.delete(setSettings); window.clearInterval(timer) }
  }, [])
  return settings
}

export async function saveSettings(next: Settings) {
  const clean = normalize(next)
  const response = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(clean) })
  if (!response.ok) throw new Error('Não foi possível salvar as configurações.')
  current = clean
  listeners.forEach((listener) => listener(current))
}

// ---------------------------------------------------------------- aparelho

const ALERT_KEY = 'pif-turn-alerts'
export function getTurnAlerts() {
  try {
    return localStorage.getItem(ALERT_KEY) === 'on'
  } catch {
    return false
  }
}
export function setTurnAlerts(on: boolean) {
  try {
    localStorage.setItem(ALERT_KEY, on ? 'on' : 'off')
  } catch {
    // sem armazenamento
  }
}

let audio: AudioContext | null = null
/** Vibra e toca um bipe curto quando é a vez desta pessoa. */
export function turnAlert() {
  try {
    navigator.vibrate?.([180, 90, 180])
  } catch {
    // sem vibração
  }
  try {
    audio ??= new AudioContext()
    const oscillator = audio.createOscillator()
    const gain = audio.createGain()
    oscillator.frequency.value = 880
    gain.gain.setValueAtTime(0.18, audio.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.35)
    oscillator.connect(gain).connect(audio.destination)
    oscillator.start()
    oscillator.stop(audio.currentTime + 0.35)
  } catch {
    // sem som
  }
}

// ---------------------------------------------------------------- arquivos

declare global {
  interface Window {
    PifAndroid?: {
      saveImage(base64Png: string, fileName: string): boolean
      shareImage?(base64Png: string, fileName: string): boolean
      saveText?(text: string, fileName: string): boolean
      setKeepScreenOn?(on: boolean): void
    }
  }
}

/** Baixa um texto como arquivo (no app vai para a pasta Downloads). */
export function downloadText(text: string, fileName: string): string {
  if (window.PifAndroid?.saveText) {
    return window.PifAndroid.saveText(text, fileName) ? `Backup salvo em Downloads/${fileName}.` : 'Não foi possível salvar o backup.'
  }
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }))
  const link = document.createElement('a')
  link.href = url
  link.download = fileName
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 5000)
  return 'Backup baixado.'
}

export async function exportBackup(): Promise<string> {
  const response = await fetch('/api/export')
  if (!response.ok) throw new Error('Não foi possível gerar o backup.')
  const text = await response.text()
  const stamp = new Date().toISOString().slice(0, 10)
  return downloadText(text, `pif-da-mesa-backup-${stamp}.json`)
}

/** Restaura mesas de um backup. Mesas que já existem neste celular são mantidas como estão. */
export async function importBackup(file: File): Promise<string> {
  let data: { rooms?: Room[]; settings?: unknown }
  try {
    data = JSON.parse(await file.text())
  } catch {
    throw new Error('Esse arquivo não é um backup do Pif da Mesa.')
  }
  const rooms = Array.isArray(data.rooms) ? data.rooms.filter((room) => room && typeof room.code === 'string' && Array.isArray(room.players)) : null
  if (!rooms) throw new Error('Esse arquivo não é um backup do Pif da Mesa.')
  let added = 0
  let kept = 0
  for (const room of rooms) {
    const response = await fetch(`/api/rooms/${encodeURIComponent(room.code)}?expect=0`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(room) })
    if (response.status === 201) {
      added += 1
      await fetch(`/api/summaries/${encodeURIComponent(room.code)}?version=1`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(buildSummary(room)) }).catch(() => undefined)
    } else {
      kept += 1
    }
  }
  if (data.settings && JSON.stringify(current) === JSON.stringify(defaultSettings)) await saveSettings(normalize(data.settings)).catch(() => undefined)
  return `${added} ${added === 1 ? 'mesa restaurada' : 'mesas restauradas'}${kept ? `, ${kept} já existia${kept === 1 ? '' : 'm'} e ficou como estava` : ''}.`
}

export async function deleteRoom(code: string) {
  const response = await fetch(`/api/rooms/${encodeURIComponent(code)}`, { method: 'DELETE' })
  if (!response.ok && response.status !== 404) throw new Error('Não foi possível apagar a mesa.')
}

// ---------------------------------------------------------------- visual (neste aparelho)

export type Layout = 'classico' | 'mesa'
export type Felt = 'verde' | 'azul' | 'vinho'
export type Look = { layout: Layout; felt: Felt; keepScreenOn: boolean }

const LOOK_KEY = 'pif-look'
function readLook(): Look {
  try {
    const data = JSON.parse(localStorage.getItem(LOOK_KEY) ?? '{}') as Partial<Look>
    return {
      layout: data.layout === 'mesa' ? 'mesa' : 'classico',
      felt: data.felt === 'azul' || data.felt === 'vinho' ? data.felt : 'verde',
      keepScreenOn: Boolean(data.keepScreenOn),
    }
  } catch {
    return { layout: 'classico', felt: 'verde', keepScreenOn: false }
  }
}

let look: Look = readLook()
const lookListeners = new Set<(value: Look) => void>()

export function applyLook(value: Look = look) {
  document.documentElement.dataset.layout = value.layout
  document.documentElement.dataset.felt = value.felt
  try {
    window.PifAndroid?.setKeepScreenOn?.(value.keepScreenOn)
  } catch {
    // fora do app
  }
}

export function setLook(patch: Partial<Look>) {
  look = { ...look, ...patch }
  try {
    localStorage.setItem(LOOK_KEY, JSON.stringify(look))
  } catch {
    // sem armazenamento: vale até fechar
  }
  applyLook(look)
  lookListeners.forEach((listener) => listener(look))
}

export function useLook(): Look {
  const [value, setValue] = useState(look)
  useEffect(() => {
    lookListeners.add(setValue)
    return () => { lookListeners.delete(setValue) }
  }, [])
  return value
}

export const canKeepScreenOn = () => Boolean(window.PifAndroid?.setKeepScreenOn)
