// Regras do Pif para o modo treino.
// 2 baralhos sem coringa (104 cartas), 9 cartas por jogador.
// Jogo = 3 cartas: trinca (mesmo valor, naipes diferentes) ou sequência (mesmo naipe,
// valores seguidos; Ás vale antes do 2 e depois do K, mas K-A-2 não vale).
// Bate quem tiver as 9 cartas formando 3 jogos.

export type Suit = 'S' | 'H' | 'D' | 'C'
export type Card = { id: string; rank: number; suit: Suit }

export const SUITS: Suit[] = ['S', 'H', 'D', 'C']
export const SUIT_SYMBOL: Record<Suit, string> = { S: '♠', H: '♥', D: '♦', C: '♣' }
export const SUIT_NAME: Record<Suit, string> = { S: 'espadas', H: 'copas', D: 'ouros', C: 'paus' }
export const isRed = (card: Card) => card.suit === 'H' || card.suit === 'D'
export const rankLabel = (rank: number) => (rank === 1 ? 'A' : rank === 11 ? 'J' : rank === 12 ? 'Q' : rank === 13 ? 'K' : String(rank))
export const cardLabel = (card: Card) => `${rankLabel(card.rank)}${SUIT_SYMBOL[card.suit]}`

export function newDeck(): Card[] {
  const cards: Card[] = []
  for (const deck of [0, 1]) for (const suit of SUITS) for (let rank = 1; rank <= 13; rank += 1) cards.push({ id: `${deck}${suit}${rank}`, rank, suit })
  return cards
}

/** Embaralha (Fisher-Yates com números aleatórios do sistema). */
export function shuffle<T>(items: T[], random: () => number = secureRandom): T[] {
  const copy = [...items]
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1))
    ;[copy[i], copy[j]] = [copy[j], copy[i]]
  }
  return copy
}

function secureRandom() {
  const buffer = new Uint32Array(1)
  crypto.getRandomValues(buffer)
  return buffer[0] / 2 ** 32
}

// ------------------------------------------------------------------ jogos

export function isTrinca(cards: Card[]) {
  return cards.length === 3 && cards.every((card) => card.rank === cards[0].rank) && new Set(cards.map((card) => card.suit)).size === 3
}

export function isSequencia(cards: Card[]) {
  if (cards.length !== 3 || !cards.every((card) => card.suit === cards[0].suit)) return false
  const ranks = cards.map((card) => card.rank).sort((a, b) => a - b)
  if (ranks[1] === ranks[0] + 1 && ranks[2] === ranks[1] + 1) return true
  // Q-K-A (Ás depois do K)
  return ranks[0] === 1 && ranks[1] === 12 && ranks[2] === 13
}

export const isGame = (cards: Card[]) => isTrinca(cards) || isSequencia(cards)

/** Divide 9 cartas em 3 jogos, se der. Devolve os jogos ou null. */
export function findWin(hand: Card[]): Card[][] | null {
  if (hand.length !== 9) return null
  const search = (rest: Card[], found: Card[][]): Card[][] | null => {
    if (!rest.length) return found
    const [first, ...others] = rest
    for (let i = 0; i < others.length; i += 1) {
      for (let j = i + 1; j < others.length; j += 1) {
        const triple = [first, others[i], others[j]]
        if (isGame(triple)) {
          const result = search(others.filter((_, index) => index !== i && index !== j), [...found, triple])
          if (result) return result
        }
      }
    }
    return null
  }
  return search(hand, [])
}

/** Com 10 cartas na mão: qual carta descartar para bater (ou null se não dá). */
export function findWinningDiscard(hand: Card[]): { discard: Card; games: Card[][] } | null {
  for (const card of hand) {
    const games = findWin(hand.filter((item) => item.id !== card.id))
    if (games) return { discard: card, games }
  }
  return null
}

// ------------------------------------------------------------------ avaliação (dicas e robôs)

/** Duas cartas que viram jogo com mais uma. */
function isPartial(a: Card, b: Card) {
  if (a.rank === b.rank) return a.suit !== b.suit
  if (a.suit !== b.suit) return false
  const low = Math.min(a.rank, b.rank)
  const high = Math.max(a.rank, b.rank)
  if (high - low <= 2) return true
  // Ás com Q ou K (Q-K-A)
  return low === 1 && high >= 12
}

/** Maior número de jogos completos e separados na mão. */
function maxGames(hand: Card[]): { count: number; used: Set<string> } {
  let best = { count: 0, used: new Set<string>() }
  const search = (rest: Card[], count: number, used: string[]) => {
    if (count > best.count) best = { count, used: new Set(used) }
    if (best.count === 3) return
    for (let a = 0; a < rest.length; a += 1) {
      for (let b = a + 1; b < rest.length; b += 1) {
        for (let c = b + 1; c < rest.length; c += 1) {
          const triple = [rest[a], rest[b], rest[c]]
          if (!isGame(triple)) continue
          search(rest.filter((_, index) => index > a && index !== b && index !== c), count + 1, [...used, ...triple.map((card) => card.id)])
        }
      }
    }
  }
  search(hand, 0, [])
  return best
}

/** Nota da mão: jogos completos valem muito, pares que quase viram jogo valem um pouco. */
export function handScore(hand: Card[]) {
  const { count, used } = maxGames(hand)
  const loose = hand.filter((card) => !used.has(card.id))
  let partials = 0
  const paired = new Set<string>()
  for (let i = 0; i < loose.length; i += 1) {
    for (let j = i + 1; j < loose.length; j += 1) {
      if (isPartial(loose[i], loose[j])) {
        partials += 1
        paired.add(loose[i].id)
        paired.add(loose[j].id)
      }
    }
  }
  return count * 100 + Math.min(partials, 6) * 12 + paired.size * 3
}

/** Melhor carta para descartar (a que deixa a mão com a maior nota). */
export function bestDiscard(hand: Card[], forbiddenId?: string): Card {
  let best = hand[0]
  let bestScore = -Infinity
  for (const card of hand) {
    if (card.id === forbiddenId) continue
    const score = handScore(hand.filter((item) => item.id !== card.id))
    // Em empate, solta a carta mais alta (menos valiosa para sequência baixa)
    if (score > bestScore || (score === bestScore && card.rank > best.rank)) {
      best = card
      bestScore = score
    }
  }
  return best
}

/** Vale a pena pegar a carta do lixo? */
export function wantsDiscard(hand: Card[], top: Card): boolean {
  const withTop = [...hand, top]
  if (findWinningDiscard(withTop) && findWinningDiscard(withTop)!.discard.id !== top.id) return true
  const before = handScore(hand)
  const after = handScore(withTop.filter((card) => card.id !== bestDiscard(withTop, top.id).id))
  return after > before + 10
}

export type Difficulty = 'facil' | 'normal'

/** Decisão do robô para a compra. */
export function botDraw(hand: Card[], top: Card | undefined, difficulty: Difficulty, random: () => number = Math.random): 'deck' | 'discard' {
  if (!top) return 'deck'
  if (difficulty === 'facil' && random() < 0.5) return 'deck'
  return wantsDiscard(hand, top) ? 'discard' : 'deck'
}

/** Decisão do robô depois de comprar (10 cartas): bater ou descartar. */
export function botAfterDraw(hand: Card[], forbiddenId: string | undefined, difficulty: Difficulty, random: () => number = Math.random): { type: 'win'; discard: Card; games: Card[][] } | { type: 'discard'; card: Card } {
  const win = findWinningDiscard(hand)
  if (win && (difficulty === 'normal' || random() < 0.85)) return { type: 'win', ...win }
  if (difficulty === 'facil' && random() < 0.35) {
    const options = hand.filter((card) => card.id !== forbiddenId)
    return { type: 'discard', card: options[Math.floor(random() * options.length)] }
  }
  return { type: 'discard', card: bestDiscard(hand, forbiddenId) }
}

/** Ordena a mão por naipe e valor (ou por valor). */
export function sortHand(hand: Card[], mode: 'naipe' | 'valor'): Card[] {
  const suitOrder: Record<Suit, number> = { S: 0, H: 1, C: 2, D: 3 }
  return [...hand].sort((a, b) => (mode === 'naipe' ? suitOrder[a.suit] - suitOrder[b.suit] || a.rank - b.rank : a.rank - b.rank || suitOrder[a.suit] - suitOrder[b.suit]))
}

/** Ids das cartas que já formam jogos completos (para a dica). */
export function cardsInGames(hand: Card[]): Set<string> {
  return maxGames(hand).used
}
