// Modo treino: Pif com cartas de verdade (aleatórias), sozinho ou contra robôs.
import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, Bot, Lightbulb, RotateCcw, Shuffle, Spade, Trophy } from 'lucide-react'
import {
  bestDiscard, botAfterDraw, botDraw, cardLabel, cardsInGames, findWinningDiscard, isRed, newDeck, rankLabel, shuffle, sortHand,
  SUIT_SYMBOL, type Card, type Difficulty,
} from './lib/pif'

type Mode = 'solo' | 'bots'
type Player = { name: string; hand: Card[]; bot: boolean }
type Game = {
  id: string
  mode: Mode
  difficulty: Difficulty
  players: Player[]
  deck: Card[]
  discard: Card[]
  turn: number
  phase: 'draw' | 'discard' | 'over'
  forbiddenId?: string
  drawnId?: string
  draws: number
  winner?: number
  winGames?: Card[][]
  log: string
  reshuffles: number
}
type Stats = { played: number; won: number; bestSolo: number | null }

const STATS_KEY = 'pif-treino-stats'
const BOT_NAMES = ['Robô Zé', 'Robô Lia', 'Robô Tião']

function readStats(): Stats {
  try {
    const data = JSON.parse(localStorage.getItem(STATS_KEY) ?? '{}') as Partial<Stats>
    return { played: data.played ?? 0, won: data.won ?? 0, bestSolo: data.bestSolo ?? null }
  } catch {
    return { played: 0, won: 0, bestSolo: null }
  }
}
function writeStats(stats: Stats) {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats))
  } catch {
    // sem armazenamento
  }
}

function deal(mode: Mode, bots: number, difficulty: Difficulty): Game {
  const deck = shuffle(newDeck())
  const players: Player[] = [{ name: 'Você', hand: deck.splice(0, 9), bot: false }]
  if (mode === 'bots') for (let i = 0; i < bots; i += 1) players.push({ name: BOT_NAMES[i], hand: deck.splice(0, 9), bot: true })
  const discard = [deck.shift()!]
  return { id: `${Date.now()}-${Math.random()}`, mode, difficulty, players, deck, discard, turn: 0, phase: 'draw', draws: 0, log: 'Sua vez: compre do monte ou pegue a carta do lixo.', reshuffles: 0 }
}

/** Compra uma carta do monte, reembaralhando o lixo quando o monte acaba. */
function takeFromDeck(game: Game): { game: Game; card: Card } {
  let { deck, discard, reshuffles } = game
  if (!deck.length) {
    const top = discard[discard.length - 1]
    deck = shuffle(discard.slice(0, -1))
    discard = top ? [top] : []
    reshuffles += 1
  }
  const [card, ...rest] = deck
  return { game: { ...game, deck: rest, discard, reshuffles }, card }
}

function nextTurn(game: Game): Game {
  const turn = game.mode === 'solo' ? 0 : (game.turn + 1) % game.players.length
  return { ...game, turn, phase: 'draw', forbiddenId: undefined, drawnId: undefined }
}

function withHand(game: Game, index: number, hand: Card[]): Player[] {
  return game.players.map((player, i) => (i === index ? { ...player, hand } : player))
}

export function PlayingCard({ card, selected, hint, fresh, onClick, small }: { card: Card; selected?: boolean; hint?: 'game' | 'discard'; fresh?: boolean; onClick?: () => void; small?: boolean }) {
  const symbol = SUIT_SYMBOL[card.suit]
  return <button type="button" className={`pcard ${isRed(card) ? 'pcard-red' : ''} ${selected ? 'pcard-selected' : ''} ${hint ? `pcard-hint-${hint}` : ''} ${small ? 'pcard-small' : ''}`} onClick={onClick} aria-label={cardLabel(card)} aria-pressed={selected}>
    <span className="pcard-corner">{rankLabel(card.rank)}<br />{symbol}</span>
    <span className="pcard-center">{symbol}</span>
    {fresh && <span className="pcard-fresh" title="Carta nova">nova</span>}
  </button>
}

function CardBack({ label }: { label?: string }) {
  return <span className="pcard pcard-back" aria-hidden={!label} aria-label={label} />
}

export function TrainingScreen({ onBack }: { onBack: () => void }) {
  const [mode, setMode] = useState<Mode>('bots')
  const [bots, setBots] = useState(2)
  const [difficulty, setDifficulty] = useState<Difficulty>('normal')
  const [hints, setHints] = useState(true)
  const [game, setGame] = useState<Game | null>(null)
  const [selected, setSelected] = useState<string | null>(null)
  const [notice, setNotice] = useState('')
  const [stats, setStats] = useState(readStats)

  const me = game?.players[0]
  const myTurn = Boolean(game && game.turn === 0 && game.phase !== 'over')
  const top = game?.discard[game.discard.length - 1]

  const inGames = useMemo(() => (me && hints ? cardsInGames(me.hand) : new Set<string>()), [me, hints])
  const suggested = useMemo(() => (me && hints && myTurn && game?.phase === 'discard' ? bestDiscard(me.hand, game.forbiddenId).id : null), [me, hints, myTurn, game?.phase, game?.forbiddenId])
  const canWin = useMemo(() => (me && myTurn && game?.phase === 'discard' ? Boolean(findWinningDiscard(me.hand)) : false), [me, myTurn, game?.phase])

  // Conta cada partida uma vez só, quando ela termina.
  const recorded = useRef<string | null>(null)
  useEffect(() => {
    if (game?.phase === 'over' && recorded.current !== game.id) {
      recorded.current = game.id
      finish(game)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game?.phase, game?.id])

  function finish(next: Game) {
    const updated: Stats = {
      played: stats.played + 1,
      won: stats.won + (next.winner === 0 ? 1 : 0),
      bestSolo: next.mode === 'solo' && next.winner === 0 ? Math.min(stats.bestSolo ?? Infinity, next.draws) : stats.bestSolo,
    }
    setStats(updated)
    writeStats(updated)
  }

  // Robôs jogam sozinhos, com uma pausa para dar tempo de ver.
  useEffect(() => {
    if (!game || game.phase === 'over') return
    const player = game.players[game.turn]
    if (!player.bot) return
    const timer = window.setTimeout(() => {
      setGame((current) => {
        if (!current || current.turn !== game.turn || current.phase !== game.phase) return current
        const bot = current.players[current.turn]
        if (current.phase === 'draw') {
          const pile = current.discard[current.discard.length - 1]
          if (botDraw(bot.hand, pile, current.difficulty) === 'discard' && pile) {
            return { ...current, discard: current.discard.slice(0, -1), players: withHand(current, current.turn, [...bot.hand, pile]), phase: 'discard', forbiddenId: pile.id, log: `${bot.name} pegou ${cardLabel(pile)} do lixo.` }
          }
          const { game: after, card } = takeFromDeck(current)
          return { ...after, players: withHand(after, current.turn, [...bot.hand, card]), phase: 'discard', log: `${bot.name} comprou do monte.` }
        }
        const action = botAfterDraw(bot.hand, current.forbiddenId, current.difficulty)
        if (action.type === 'win') {
          return { ...current, players: withHand(current, current.turn, bot.hand.filter((card) => card.id !== action.discard.id)), discard: [...current.discard, action.discard], phase: 'over', winner: current.turn, winGames: action.games, log: `${bot.name} bateu!` }
        }
        const after: Game = { ...current, players: withHand(current, current.turn, bot.hand.filter((card) => card.id !== action.card.id)), discard: [...current.discard, action.card], log: `${bot.name} descartou ${cardLabel(action.card)}.` }
        const next = nextTurn(after)
        return next.turn === 0 ? { ...next, log: `${after.log} Sua vez.` } : next
      })
    }, game.phase === 'draw' ? 750 : 650)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game?.turn, game?.phase, game?.players])

  function start() {
    setGame(deal(mode, bots, difficulty))
    setSelected(null)
    setNotice('')
  }

  function drawDeck() {
    if (!game || !myTurn || game.phase !== 'draw') return
    const { game: after, card } = takeFromDeck(game)
    setGame({ ...after, players: withHand(after, 0, [...game.players[0].hand, card]), phase: 'discard', drawnId: card.id, draws: game.draws + 1, log: `Você comprou ${cardLabel(card)}. Agora descarte uma carta${hints ? ' ou bata' : ''}.` })
    setNotice(after.reshuffles > game.reshuffles ? 'O monte acabou e o lixo foi embaralhado de novo.' : '')
  }

  function drawPile() {
    if (!game || !myTurn || game.phase !== 'draw' || !top) return
    setGame({ ...game, discard: game.discard.slice(0, -1), players: withHand(game, 0, [...game.players[0].hand, top]), phase: 'discard', forbiddenId: top.id, drawnId: top.id, draws: game.draws + 1, log: `Você pegou ${cardLabel(top)} do lixo. Ela não pode ser descartada agora.` })
    setNotice('')
  }

  function discardSelected() {
    if (!game || !me || !myTurn || game.phase !== 'discard') return
    const card = me.hand.find((item) => item.id === selected)
    if (!card) {
      setNotice('Toque numa carta da sua mão para escolher o descarte.')
      return
    }
    if (card.id === game.forbiddenId) {
      setNotice('A carta que você pegou do lixo não pode voltar para o lixo na mesma jogada.')
      return
    }
    const after: Game = { ...game, players: withHand(game, 0, me.hand.filter((item) => item.id !== card.id)), discard: [...game.discard, card], log: `Você descartou ${cardLabel(card)}.` }
    setGame(nextTurn(game.mode === 'solo' ? { ...after, log: `${after.log} Compre de novo.` } : after))
    setSelected(null)
    setNotice('')
  }

  function bater() {
    if (!game || !me || !myTurn || game.phase !== 'discard') return
    const win = findWinningDiscard(me.hand)
    if (!win) {
      setNotice('Ainda não dá para bater: 9 cartas precisam formar 3 jogos (trincas com naipes diferentes ou sequências do mesmo naipe).')
      return
    }
    const ended: Game = { ...game, players: withHand(game, 0, me.hand.filter((card) => card.id !== win.discard.id)), discard: [...game.discard, win.discard], phase: 'over', winner: 0, winGames: win.games, log: 'Você bateu!' }
    setGame(ended)
    setSelected(null)
    setNotice('')
  }

  function sortMine(sortMode: 'naipe' | 'valor') {
    if (!game || !me) return
    setGame({ ...game, players: withHand(game, 0, sortHand(me.hand, sortMode)) })
  }

  // ------------------------------------------------------------ configuração
  if (!game) {
    return <main className="gate-shell training-shell">
      <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
      <section className="gate-panel training-setup">
        <button type="button" className="text-action back-action" onClick={onBack}><ArrowLeft size={15} /> Voltar ao início</button>
        <span className="section-kicker">MODO TREINO · SEM DINHEIRO</span>
        <h1>Treinar Pif</h1>
        <p className="gate-copy">2 baralhos embaralhados (104 cartas), 9 cartas na mão. Bate quem formar 3 jogos: trinca de naipes diferentes ou sequência do mesmo naipe (A-2-3 e Q-K-A valem).</p>
        <div className="layout-options" role="radiogroup" aria-label="Modo">
          <button type="button" role="radio" aria-checked={mode === 'bots'} className={`layout-option ${mode === 'bots' ? 'selected' : ''}`} onClick={() => setMode('bots')}><Bot size={20} /><strong>Contra o computador</strong><small>Robôs compram, descartam e batem</small></button>
          <button type="button" role="radio" aria-checked={mode === 'solo'} className={`layout-option ${mode === 'solo' ? 'selected' : ''}`} onClick={() => setMode('solo')}><Spade size={20} /><strong>Sozinho</strong><small>Bata com o menor número de compras</small></button>
        </div>
        {mode === 'bots' && <>
          <div className="setting-field">Quantos robôs?<div className="felt-options">{[1, 2, 3].map((count) => <button type="button" key={count} className={`felt-option ${bots === count ? 'selected' : ''}`} onClick={() => setBots(count)}>{count}</button>)}</div></div>
          <div className="setting-field">Dificuldade<div className="felt-options">
            <button type="button" className={`felt-option ${difficulty === 'facil' ? 'selected' : ''}`} onClick={() => setDifficulty('facil')}>Fácil</button>
            <button type="button" className={`felt-option ${difficulty === 'normal' ? 'selected' : ''}`} onClick={() => setDifficulty('normal')}>Normal</button>
          </div></div>
        </>}
        <label className="solo-toggle"><input id="training-hints" type="checkbox" checked={hints} onChange={(event) => setHints(event.target.checked)} /><span><strong>Mostrar dicas</strong><small>Marca as cartas que já formam jogo, sugere o descarte e avisa quando dá para bater.</small></span></label>
        <button type="button" className="button button-primary full-button" onClick={start}><Shuffle size={16} /> Embaralhar e começar</button>
        <p className="training-stats">Partidas: <b>{stats.played}</b> · Vitórias: <b>{stats.won}</b>{stats.bestSolo !== null ? <> · Recorde sozinho: <b>{stats.bestSolo} compras</b></> : null}</p>
      </section>
    </main>
  }

  // ------------------------------------------------------------ partida
  const opponents = game.players.slice(1)
  return <main className="training-table">
    <header className="training-top">
      <button type="button" className="share-button" onClick={() => { setGame(null); setSelected(null) }}><ArrowLeft size={16} /><span>Sair</span></button>
      <strong>Treino · {game.mode === 'solo' ? 'sozinho' : `${opponents.length} ${opponents.length === 1 ? 'robô' : 'robôs'}`}</strong>
      <span className="training-count">{game.draws} {game.draws === 1 ? 'compra' : 'compras'}</span>
    </header>

    {opponents.length > 0 && <div className="training-opponents">
      {opponents.map((player, index) => <div key={player.name} className={`training-opponent ${game.turn === index + 1 && game.phase !== 'over' ? 'is-turn' : ''}`}>
        <span className="training-opponent-name"><Bot size={14} /> {player.name}</span>
        <span className="training-backs">{player.hand.slice(0, 9).map((card) => <i key={card.id} />)}</span>
        <small>{game.turn === index + 1 && game.phase !== 'over' ? 'pensando...' : `${player.hand.length} cartas`}</small>
      </div>)}
    </div>}

    <div className="training-center">
      <button type="button" className={`training-pile ${myTurn && game.phase === 'draw' ? 'can-take' : ''}`} onClick={drawDeck} disabled={!myTurn || game.phase !== 'draw'} aria-label={`Comprar do monte (${game.deck.length} cartas)`}>
        <CardBack />
        <small>Monte · {game.deck.length}</small>
      </button>
      <div className={`training-pile ${myTurn && game.phase === 'draw' && top ? 'can-take' : ''}`}>
        {top ? <PlayingCard card={top} onClick={drawPile} /> : <span className="pcard pcard-empty" />}
        <small>Lixo</small>
      </div>
    </div>

    <p className="training-log" role="status">{game.log}</p>
    {notice && <p className="training-notice" role="alert">{notice}</p>}

    {me && <section className="training-hand-area">
      <div className="training-hand">
        {me.hand.map((card) => <PlayingCard key={card.id} card={card} selected={selected === card.id} fresh={card.id === game.drawnId} hint={suggested === card.id ? 'discard' : inGames.has(card.id) ? 'game' : undefined} onClick={() => setSelected(selected === card.id ? null : card.id)} />)}
      </div>
      <div className="training-actions">
        <button type="button" className="button button-secondary" onClick={() => sortMine('naipe')}>Por naipe</button>
        <button type="button" className="button button-secondary" onClick={() => sortMine('valor')}>Por número</button>
        <button type="button" className={`button button-secondary ${hints ? 'is-on' : ''}`} onClick={() => setHints(!hints)}><Lightbulb size={15} /> Dica {hints ? 'ligada' : 'desligada'}</button>
      </div>
      <div className="training-actions">
        <button type="button" className="button button-primary" disabled={!myTurn || game.phase !== 'discard'} onClick={discardSelected}>Descartar {selected && me.hand.find((card) => card.id === selected) ? cardLabel(me.hand.find((card) => card.id === selected)!) : ''}</button>
        <button type="button" className={`button button-finish ${hints && canWin ? 'can-win' : ''}`} disabled={!myTurn || game.phase !== 'discard'} onClick={bater}><Trophy size={15} /> Bater</button>
      </div>
      {hints && <p className="form-hint training-legend"><span className="legend-game" /> já forma jogo · <span className="legend-discard" /> sugestão de descarte</p>}
    </section>}

    {game.phase === 'over' && <div className="modal-backdrop" role="presentation">
      <section className="modal training-result" role="dialog" aria-modal="true" aria-labelledby="training-result-title">
        <span className="section-kicker">{game.winner === 0 ? 'PARABÉNS' : 'FIM DA PARTIDA'}</span>
        <h2 id="training-result-title">{game.winner === 0 ? 'Você bateu!' : `${game.players[game.winner ?? 0].name} bateu`}</h2>
        <p className="form-hint">{game.winner === 0 ? `Com ${game.draws} ${game.draws === 1 ? 'compra' : 'compras'}.${game.mode === 'solo' && stats.bestSolo === game.draws ? ' Novo recorde!' : ''}` : 'Os jogos dele:'}</p>
        <div className="training-games">{game.winGames?.map((triple, index) => <div className="training-game" key={index}>{triple.map((card) => <PlayingCard key={card.id} card={card} small />)}</div>)}</div>
        <button type="button" className="button button-primary full-button" onClick={start}><RotateCcw size={16} /> Jogar de novo</button>
        <button type="button" className="button button-secondary full-button" onClick={() => setGame(null)}>Mudar o modo</button>
        <button type="button" className="text-action" onClick={onBack}>Voltar ao início</button>
      </section>
    </div>}
  </main>
}
