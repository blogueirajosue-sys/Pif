import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import {
  ArrowRight,
  CalendarDays,
  Check,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  Clock3,
  Copy,
  Heart,
  History,
  LayoutGrid,
  LogOut,
  Plus,
  ShieldCheck,
  Settings2,
  Spade,
  Undo2,
  UsersRound,
  PencilLine,
  X,
} from 'lucide-react'
import './App.css'
import { connect, createRoom, mutateRoom, subscribeRoom, subscribeRoomList, type Platform, type Room, type RoomSummary } from './lib/roomApi'
import { playerForUser, type Action } from './lib/engine'
import qrcode from 'qrcode-generator'
import { HistoryScreen, ResultView, RoundsHistory } from './extras'
import { SettingsScreen } from './SettingsScreen'
import { applyLook, getTurnAlerts, setLook, turnAlert, useLook, useSettings } from './lib/settings'
import { playerColor } from './lib/format'
import { TableView } from './TableView'
import { TrainingScreen } from './Training'

const isHostDevice = ['localhost', '127.0.0.1'].includes(window.location.hostname)

/** Endereço que os amigos abrem: o IP do celular na rede local. */
async function networkBase(): Promise<string | null> {
  if (!isHostDevice) return window.location.origin
  try {
    const response = await fetch('/api/info')
    const data = await response.json() as { addresses?: string[]; port?: number }
    const address = data.addresses?.[0]
    return address ? `http://${address}:${data.port ?? 8080}` : null
  } catch {
    return null
  }
}

function useNetworkBase() {
  const [base, setBase] = useState<string | null | undefined>(undefined)
  useEffect(() => {
    let active = true
    const load = () => { void networkBase().then((value) => { if (active) setBase(value) }) }
    load()
    const timer = window.setInterval(load, 8000)
    return () => { active = false; window.clearInterval(timer) }
  }, [])
  return base
}

function QrCode({ text }: { text: string }) {
  const svg = useMemo(() => {
    const code = qrcode(0, 'M')
    code.addData(text)
    code.make()
    return code.createSvgTag({ cellSize: 4, margin: 2, scalable: true })
  }, [text])
  return <div className="qr-box" aria-label={`QR code para ${text}`} dangerouslySetInnerHTML={{ __html: svg }} />
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

function NetworkInvite({ code, title }: { code?: string; title: string }) {
  const base = useNetworkBase()
  const [copied, setCopied] = useState(false)
  if (base === undefined) return null
  if (base === null) return <div className="network-invite network-missing">
    <strong>Sem rede para os amigos</strong>
    <span>Ligue o roteador do celular (hotspot) ou conecte num Wi-Fi. O link aparece aqui sozinho.</span>
  </div>
  const link = code ? `${base}/#${code}` : `${base}/`
  return <div className="network-invite">
    <QrCode text={link} />
    <div className="network-invite-copy">
      <span className="section-kicker">{title}</span>
      <strong className="network-link">{link}</strong>
      <span>Os amigos precisam estar no mesmo Wi-Fi ou no roteador deste celular. Podem ler o QR code com a câmera.</span>
      <button type="button" className="button button-secondary" onClick={() => { void copyText(link).then((ok) => { setCopied(ok); window.setTimeout(() => setCopied(false), 1600) }) }}>{copied ? <Check size={15} /> : <Copy size={15} />} {copied ? 'Copiado' : 'Copiar link'}</button>
    </div>
  </div>
}

type Tab = 'overview' | 'rounds' | 'ledger' | 'activity'
type Dialog = 'solo-round' | 'add-player' | 'undo' | 'rename' | 'announce-round' | 'round-result' | 'entry' | 'correct-round' | 'exit' | null
function money(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
}

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('')
}

function localDate(value: string | null) {
  if (!value) return 'Ainda não iniciada'
  return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value))
}

function timeOnly(value: string) {
  return new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(new Date(value))
}


function getRoomCodeFromUrl() {
  const fromHash = window.location.hash.replace('#', '').trim().toUpperCase()
  if (/^[2-9A-HJ-NP-Z]{8}$/.test(fromHash)) return fromHash
  try {
    return new URLSearchParams(window.location.search).get('mesa')?.trim().toUpperCase() ?? ''
  } catch {
    return ''
  }
}

function setUrlCode(code: string) {
  try {
    window.history.replaceState({}, '', code ? `${window.location.pathname}${window.location.search}#${code}` : `${window.location.pathname}${window.location.search}`)
  } catch {
    // o visualizador pode bloquear; o código continua na tela
  }
}

const statusLabel: Record<Room['status'], string> = { waiting: 'Aguardando início', playing: 'Em andamento', finished: 'Encerrada' }

function OpenRooms({ rooms, onOpen }: { rooms: RoomSummary[]; onOpen: (code: string) => void }) {
  const visible = rooms.filter((room) => room.status !== 'finished').slice(0, 8)
  if (!visible.length) return null
  return <div className="open-rooms">
    <span className="section-kicker">MESAS ABERTAS</span>
    {visible.map((room) => <button type="button" className="open-room" key={room.code} onClick={() => onOpen(room.code)}>
      <span className="open-room-name"><strong>{room.name}</strong><small>{room.host ? `de ${room.host}` : ''} · {room.activePlayers} {room.activePlayers === 1 ? 'jogador' : 'jogadores'}{room.solo ? ' · solo' : ''}</small></span>
      <span className={`open-room-status status-${room.status}`}>{statusLabel[room.status]}</span>
      <ArrowRight size={15} />
    </button>)}
  </div>
}

function HomeScreen({ onCreate, onOpen, onHistory, onSettings, onTraining, message, busy, rooms }: {
  onSettings: () => void
  onTraining: () => void
  onCreate: (name: string, playerName: string, soloNames?: string[]) => Promise<void>
  onOpen: (code: string) => void
  onHistory: () => void
  message: string
  busy: boolean
  rooms: RoomSummary[]
}) {
  const [tableName, setTableName] = useState('Pif da sexta')
  const [playerName, setPlayerName] = useState('')
  const [code, setCode] = useState(getRoomCodeFromUrl())
  const [solo, setSolo] = useState(false)
  const [soloText, setSoloText] = useState('')

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    await onCreate(tableName, playerName, solo ? soloText.split(/[\n,;]+/).map((item) => item.trim()).filter(Boolean) : undefined)
  }

  function open(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    onOpen(code)
  }

  return <main className="gate-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel home-panel">
      {isHostDevice && <NetworkInvite title="MESA LIGADA NESTE CELULAR" />}
      <span className="section-kicker">PARTIDA PRESENCIAL</span>
      <h1>Joguem. Os acertos ficam por nossa conta.</h1>
      <p className="gate-copy">Abra uma sala, convide os amigos e registre rodadas e acertos combinados pela mesa.</p>
      <form className="form-stack" onSubmit={create}>
        <label>Nome da mesa<input value={tableName} onChange={(event) => setTableName(event.target.value)} maxLength={80} required /></label>
        <label>Seu nome<input value={playerName} onChange={(event) => setPlayerName(event.target.value)} maxLength={50} placeholder="Ex.: Marina" required /></label>
        <label className="solo-toggle"><input id="solo-mode" type="checkbox" checked={solo} onChange={(event) => setSolo(event.target.checked)} /><span><strong>Modo solo</strong><small>Os amigos não entram pelo link: você coloca o nome de cada um e marca tudo.</small></span></label>
        {solo && <label>Nomes dos outros jogadores<textarea id="solo-names" value={soloText} onChange={(event) => setSoloText(event.target.value)} rows={4} placeholder={'Um por linha. Ex.:\nBia\nCaio\nDudu'} required /></label>}
        <button className="button button-primary full-button" disabled={busy} type="submit"><Plus size={16} /> {busy ? 'Criando...' : solo ? 'Criar mesa solo' : 'Criar sala'}</button>
      </form>
      <button type="button" className="button button-secondary full-button history-button" onClick={onHistory}><History size={16} /> Histórico geral: quem ganhou e perdeu</button>
      <button type="button" className="button button-secondary full-button training-button" onClick={onTraining}><Spade size={16} /> Treinar com cartas (sozinho ou contra robôs)</button>
      <button type="button" className="text-action settings-link" onClick={onSettings}><Settings2 size={15} /> Configurações e backup</button>
      <div className="gate-or"><span />ou entrar numa mesa<span /></div>
      <OpenRooms rooms={rooms} onOpen={onOpen} />
      <form className="form-stack" onSubmit={open}>
        <label>Código da sala<input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} maxLength={8} placeholder="Ex.: 8H2K7Q9M" required /></label>
        <button className="button button-secondary full-button" disabled={busy} type="submit"><ArrowRight size={16} /> Entrar na sala</button>
      </form>
      <p className="gate-note"><ShieldCheck size={15} /> Sem cadastro. Todo mundo no mesmo Wi-Fi ou no roteador do celular do anfitrião.</p>
      {message && <p className="gate-message" role="alert">{message}</p>}
    </section>
    <p className="gate-foot">As mesas e o histórico ficam salvos no celular do anfitrião.</p>
  </main>
}

function JoinScreen({ room, code, onJoin, onResume, message, busy }: {
  room: Room
  code: string
  onJoin: (name: string) => Promise<void>
  onResume: (name: string) => void
  message: string
  busy: boolean
}) {
  const [name, setName] = useState('')

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (canJoin) await onJoin(name)
    else onResume(name)
  }

  const canJoin = room.status !== 'finished' && !room.activeRound
  return <main className="gate-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel join-panel">
      <span className="section-kicker">CONVITE PARA A MESA</span>
      <h1>{room.name}</h1>
      <p className="gate-copy">{room.players.filter((player) => player.inGame).length} jogadores na partida <span className="bullet">·</span> {room.status === 'waiting' ? 'Aguardando início' : room.status === 'playing' ? room.activeRound ? `Rodada ${room.activeRound.number} em andamento` : 'Entre rodadas' : 'Partida encerrada'}</p>
      <form className="form-stack" onSubmit={submit}>
        <label>Seu nome<input value={name} onChange={(event) => setName(event.target.value)} maxLength={50} autoFocus placeholder="Como te chamam na mesa?" required /></label>
        <button className="button button-primary full-button" disabled={busy} type="submit"><UsersRound size={16} /> {canJoin ? busy ? 'Entrando...' : 'Entrar na sala' : 'Ver minha partida'}</button>
      </form>
      {!canJoin && <div className="gate-locked"><ShieldCheck size={18} /><span>{room.status === 'playing' ? 'Esta rodada já começou. Você poderá entrar quando ela terminar ou for cancelada.' : 'A partida terminou. Informe o nome com que entrou para ver seus acertos.'}</span></div>}
      {message && <p className="gate-message" role="alert">{message}</p>}
      <p className="gate-room-code">Código da sala <strong>{code}</strong></p>
    </section>
    <p className="gate-foot">Não precisa instalar nada. Abra pelo navegador do celular.</p>
  </main>
}

function ActivityList({ room }: { room: Room }) {
  return <div className="activity-list">
          {[...room.activity].reverse().map((event) => <article className="activity-item" key={event.id}>
            <span className={`activity-icon activity-${event.type}`}><History size={15} /></span>
            <div className="activity-copy"><strong>{event.message}</strong><span>{event.actor} <span className="bullet">·</span> {localDate(event.createdAt)}</span></div>
          </article>)}
  </div>
}

function RoundControls({ room, playerId, isHost, busy, onCardCheck, onResponse, onDouble, onCancelVote, onDialog }: {
  room: Room
  playerId: string
  isHost: boolean
  busy: boolean
  onCardCheck: (count: number) => Promise<void>
  onResponse: (choice: 'play' | 'fold') => Promise<void>
  onDouble: () => Promise<void>
  onCancelVote: () => Promise<void>
  onDialog: (dialog: Dialog) => void
}) {
  const hand = room.activeRound
  if (!hand) return null
  const player = room.players.find((item) => item.id === playerId)
  const response = hand.responses?.[playerId]
  const threshold = Math.floor(hand.playingPlayerIds.length / 2) + 1
  const playerName = room.players.find((item) => item.id === hand.firstPlayerId)?.name ?? 'quem abre'

  return <div className="active-round-actions">
    {hand.phase === 'dealing' && hand.playerIds.includes(playerId) && !hand.cardConfirmations.includes(playerId) && <>
      <button className="button button-primary" disabled={busy} onClick={() => void onCardCheck(9)}><Check size={16} /> Tudo certo, pode começar</button>
      <p className="hand-instructions">Se a mesa discordar da distribuição, a maioria pode cancelar a mão sem mexer nos saldos.</p>
    </>}
    {hand.phase === 'dealing' && hand.cardConfirmations.includes(playerId) && <span className="waiting-host"><Check size={15} /> Você confirmou a distribuição. {hand.cardConfirmations.length}/{hand.playerIds.length}</span>}
    {hand.phase === 'announcing' && playerId === hand.firstPlayerId && <button className="button button-primary" onClick={() => onDialog('announce-round')}><CircleDollarSign size={16} /> Anunciar valor</button>}
    {hand.phase === 'announcing' && playerId !== hand.firstPlayerId && <span className="waiting-host"><Clock3 size={15} /> Aguardando {playerName} anunciar</span>}
    {hand.phase === 'responding' && playerId === hand.firstPlayerId && <span className="waiting-host"><ShieldCheck size={15} /> Você anunciou: fica na mão e não pode dobrar</span>}
    {hand.phase === 'responding' && playerId !== hand.firstPlayerId && response === 'pending' && <>
      <button className="button button-primary" disabled={busy} onClick={() => void onResponse('play')}><Check size={16} /> Vou jogar</button>
      <button className="button button-secondary" disabled={busy} onClick={() => void onResponse('fold')}>Sair desta mão</button>
    </>}
    {hand.phase === 'responding' && response === 'play' && playerId !== hand.firstPlayerId && !hand.doubledByPlayerIds.includes(playerId) && <button className="button button-secondary" disabled={busy} onClick={() => void onDouble()}>Dobrar para {money((hand.value ?? 0) * 2)}</button>}
    {hand.phase === 'responding' && response === 'play' && <span className="vote-hint">Você confirmou; aguardando os outros. Quem sai antes do jogo não altera o saldo.</span>}
    {hand.phase === 'responding' && response === 'fold' && <span className="folded-note">Você saiu desta mão; seu saldo não muda.</span>}
    {hand.phase === 'playing' && isHost && <button className="button button-primary" onClick={() => onDialog('round-result')}><Check size={16} /> Registrar quem bateu</button>}
    {hand.phase === 'playing' && hand.playingPlayerIds.includes(playerId) && <button className="button button-secondary cancel-vote-button" disabled={hand.cancelVotes.includes(playerId) || busy} onClick={() => void onCancelVote()}><X size={16} /> {hand.cancelVotes.includes(playerId) ? 'Voto registrado' : 'Cancelar a partida'} <span>{hand.cancelVotes.length}/{threshold}</span></button>}
    {hand.phase === 'playing' && <span className="vote-hint">A maioria de quem confirmou esta mão pode cancelar a partida sem alterar os saldos.</span>}
    {player && !hand.playerIds.includes(playerId) && <span className="waiting-host"><Clock3 size={15} /> Você ficou fora desta mão.</span>}
  </div>
}

function RoomDashboard({ room, playerId, isHost, tab, setTab, message, busy, onShare, onExit, onNewRound, onStart, onCancelVote, onCardCheck, onResponse, onDouble, onDialog }: {
  room: Room
  playerId: string
  isHost: boolean
  tab: Tab
  setTab: (tab: Tab) => void
  message: string
  busy: boolean
  onShare: () => Promise<void>
  onExit: () => void
  onNewRound: () => Promise<void>
  onStart: () => Promise<void>
  onCancelVote: () => Promise<void>
  onCardCheck: (count: number) => Promise<void>
  onResponse: (choice: 'play' | 'fold') => Promise<void>
  onDouble: () => Promise<void>
  onDialog: (dialog: Dialog, roundId?: string) => void
}) {
  const [copied, setCopied] = useState(false)
  const players = room.players.filter((player) => player.inGame)
  const currentPlayer = room.players.find((player) => player.id === playerId)
  const activeRound = room.activeRound
  const activeHandPlayerIds = activeRound ? [...activeRound.playerIds, ...activeRound.foldedPlayerIds.filter((id) => !activeRound.playerIds.includes(id))] : []
  const balanceByPlayer = useMemo(() => {
    const balances = new Map(room.players.map((player) => [player.id, 0]))
    for (const round of room.rounds) {
      if (!round.winnerId) continue
      const participantIds = round.playerIds ?? room.players.map((player) => player.id)
      if (!participantIds.includes(round.winnerId)) continue
      const stake = Math.round(round.value * 100)
      for (const playerId of participantIds) {
        if (!balances.has(playerId)) continue
        const delta = playerId === round.winnerId ? stake * (participantIds.length - 1) : -stake
        balances.set(playerId, (balances.get(playerId) ?? 0) + delta)
      }
    }
    for (const entry of room.entries) balances.set(entry.playerId, (balances.get(entry.playerId) ?? 0) + Math.round(entry.amount * 100))
    return new Map([...balances].map(([playerId, amount]) => [playerId, amount / 100]))
  }, [room.players, room.entries, room.rounds])
  const difference = [...balanceByPlayer.values()].reduce((sum, amount) => sum + Math.round(amount * 100), 0)
  const creditorsTotal = [...balanceByPlayer.values()].filter((balance) => balance > 0).reduce((sum, balance) => sum + balance, 0)
  const look = useLook()
  const nextOpener = room.players.find((player) => player.id === room.nextOpenerId)
  const canStartRound = isHost || (Boolean(nextOpener) && nextOpener?.id === playerId)
  const statusText = room.status === 'waiting' ? 'Aguardando jogadores' : room.status === 'playing' ? 'Partida em andamento' : 'Jogo encerrado'

  async function copyInvite() {
    await onShare()
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  return <main className="app-shell">
    <header className="topbar">
      <a className="brand" href="#mesa"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></a>
      <div className="topbar-center"><span className={`live-dot ${room.status === 'finished' ? 'closed-dot' : ''}`} /> {statusText}<span className="topbar-divider" /><span className="table-select">{room.name}</span><span className="table-code">Sala {room.code}</span></div>
      <div className="topbar-actions">
        <button className="share-button" onClick={() => setLook({ layout: look.layout === 'mesa' ? 'classico' : 'mesa' })} title="Trocar o visual"><LayoutGrid size={16} /><span>{look.layout === 'mesa' ? 'Clássico' : 'Mesa'}</span></button>
        {room.status !== 'finished' && !room.solo && <button className="share-button" onClick={copyInvite} title="Copiar convite">{copied ? <Check size={17} /> : <Copy size={17} />}<span>{copied ? 'Copiado' : 'Convidar'}</span></button>}
        <button className="share-button exit-button" onClick={onExit} title="Sair da mesa e ver o resultado"><LogOut size={16} /><span>Sair</span></button>
      </div>
    </header>

    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-label">{room.name.toUpperCase()}</div>
        <button className={`side-link ${tab === 'overview' ? 'active' : ''}`} onClick={() => setTab('overview')}><CircleDollarSign size={18} /> Visão geral</button>
        <button className={`side-link ${tab === 'rounds' ? 'active' : ''}`} onClick={() => setTab('rounds')}><Spade size={18} /> Rodadas <span className="side-count">{room.rounds.length}</span></button>
        <button className={`side-link ${tab === 'ledger' ? 'active' : ''}`} onClick={() => setTab('ledger')}><ClipboardList size={18} /> Acertos <span className="side-count">{room.entries.length}</span></button>
        <button className={`side-link ${tab === 'activity' ? 'active' : ''}`} onClick={() => setTab('activity')}><History size={18} /> Histórico</button>
        <div className="sidebar-rule" />
        <div className="sidebar-label players-heading">NA MESA <span>{players.length}</span></div>
        <div className="player-list">{players.map((player) => <div className="sidebar-player" key={player.id}>
          <span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span><span className="sidebar-player-name">{player.name}</span>
          <span className={`mini-balance ${(balanceByPlayer.get(player.id) ?? 0) >= 0 ? 'positive' : 'negative'}`}>{money(balanceByPlayer.get(player.id) ?? 0)}</span>
        </div>)}</div>
        <div className="sidebar-bottom"><div className="privacy-note"><ShieldCheck size={16} /><span>Participantes mudam entre mãos.<br />Cada mudança fica no histórico.</span></div>
          <div className="profile-button"><span className="organizer-avatar small">{initials(currentPlayer?.name ?? '?')}</span><span><strong>{currentPlayer?.name ?? 'Participante'}</strong><small>{currentPlayer?.inGame ? isHost ? 'Anfitrião' : 'Jogador' : 'Saiu da partida'}</small></span><ChevronDown size={15} /></div>
        </div>
      </aside>

      <section className="main-content room-panel">
        <div className="page-heading">
          <div><div className="eyebrow"><CalendarDays size={14} /> {room.status === 'waiting' ? `CRIADA ${localDate(room.createdAt)}` : `COMEÇOU ${localDate(room.startedAt)}`}</div>
            <h1>{tab === 'rounds' ? 'Rodadas' : tab === 'ledger' ? 'Acertos manuais' : tab === 'activity' ? 'Histórico da mesa' : room.status === 'waiting' ? 'Todo mundo na mesa?' : room.status === 'finished' ? 'Partida encerrada' : 'A partida começou'}</h1>
            <p className="heading-subtitle">{room.status === 'waiting' ? 'Convide os amigos. A lista muda entre mãos e fica travada durante a rodada.' : room.status === 'finished' ? `Encerrada ${localDate(room.finishedAt)}` : 'Cartas na mesa, acertos registrados à parte.'}</p>
          </div>
          <div className="heading-actions">
            {room.status === 'playing' && activeRound && tab !== 'overview' && <RoundControls room={room} playerId={playerId} isHost={isHost} busy={busy} onCardCheck={onCardCheck} onResponse={onResponse} onDouble={onDouble} onCancelVote={onCancelVote} onDialog={onDialog} />}
            {room.status === 'playing' && !activeRound && room.solo && isHost && <>
              <button className="button button-primary" onClick={() => onDialog('solo-round')}><Spade size={16} /> Registrar rodada</button>
              <button className="button button-secondary" onClick={() => onDialog('add-player')}><UsersRound size={16} /> Adicionar jogador</button>
            </>}
            {room.status === 'playing' && !activeRound && !room.solo && canStartRound && <button className="button button-primary" disabled={busy} onClick={() => void onNewRound()}><Spade size={16} /> Começar rodada</button>}
            {room.status === 'playing' && !activeRound && isHost && tab !== 'ledger' && <button className="button button-secondary" onClick={() => onDialog('entry')}><Plus size={17} /> Lançar acerto</button>}
          </div>
        </div>
        {message && <div className="notice" role="status">{message}</div>}

        {tab === 'overview' && room.status === 'waiting' && <div className="lobby-grid">
          <section className="panel lobby-players">
            <div className="panel-heading"><div><span className="section-kicker">CONFIRMADOS</span><h2>Quem está na mesa</h2></div><span className="count-pill">{players.length} jogadores</span></div>
            {players.map((player) => <div className="lobby-player" key={player.id}><span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span><strong>{player.name}</strong>{player.id === room.ownerPlayerId && <span className="host-tag">ANFITRIÃO</span>}{player.id === playerId && !isHost && <button className="leave-roster" onClick={onExit}>Sair da lista</button>}</div>)}
            <p className="lobby-lock-note"><ShieldCheck size={15} /> A lista muda somente entre rodadas; durante uma rodada, participantes ficam travados.</p>
          </section>
          <section className="panel lobby-start">
            <span className="section-kicker">PRÓXIMO PASSO</span><h2>Quando todo mundo estiver aqui, comece.</h2>
            <p>Novos amigos podem entrar entre rodadas. O anfitrião escolhe quem participa de cada mão; quem fica de fora não ganha nem perde nela.</p>
            <NetworkInvite code={room.code} title={`CONVITE · SALA ${room.code}`} />
            {isHost ? <button className="button button-primary full-button start-button" disabled={players.length < 2} onClick={() => void onStart()}><Spade size={16} /> Iniciar partida</button> : <div className="waiting-host"><Clock3 size={16} /> Aguardando o anfitrião iniciar</div>}
            {players.length < 2 && <small className="start-hint">Convide pelo menos mais uma pessoa.</small>}
          </section>
          <section className="panel lobby-history"><div className="panel-heading"><div><span className="section-kicker">ATIVIDADE</span><h2>O que aconteceu</h2></div><button className="text-action" onClick={() => setTab('activity')}>Ver histórico <ArrowRight size={14} /></button></div><ActivityList room={{ ...room, activity: room.activity.slice(-3) }} /></section>
        </div>}

        {tab === 'overview' && room.status === 'playing' && <>
          {look.layout === 'mesa' && <TableView room={room} playerId={playerId} balances={balanceByPlayer} />}
          {activeRound && <section className="panel active-round-panel">
            <div className="active-round-header"><div><span className="section-kicker">MÃO {activeRound.number} · {activeRound.phase === 'dealing' ? 'CONFERIR CARTAS' : activeRound.phase === 'announcing' ? 'ANÚNCIO DO ABRIDOR' : activeRound.phase === 'responding' ? 'CONFIRMAR APOSTA' : 'JOGO EM ANDAMENTO'}</span><h2>{activeRound.phase === 'dealing' ? 'Cada pessoa confere nove cartas' : activeRound.phase === 'announcing' ? 'A vez de anunciar o valor' : activeRound.phase === 'responding' ? 'Quem vai jogar esta mão?' : 'Cartas na mesa'}</h2></div>{activeRound.value !== null && <span className="count-pill">{money(activeRound.value)} por jogador</span>}</div>
            {activeRound.phase === 'dealing' && (activeRound.lastDealError
              ? <p className="hand-instructions redeal-warning">A distribuição foi aberta para conferência, mas a mesa pode seguir em frente. Se houver discordância, a maioria pode cancelar a mão.</p>
              : <p className="hand-instructions">A regra de nove cartas é opcional; se todos estiverem de frente, a mão pode começar sem contar cada carta.</p>)}
            {activeRound.phase === 'announcing' && <p className="hand-instructions">Todos confirmaram a distribuição. {room.players.find((player) => player.id === activeRound.firstPlayerId)?.name} anuncia o primeiro valor.</p>}
            <div className="active-round-players">{activeHandPlayerIds.map((participantId) => {
              const player = room.players.find((item) => item.id === participantId)
              if (!player) return null
              const response = activeRound.responses?.[participantId]
              const checked = activeRound.cardConfirmations?.includes(participantId)
              return <span className={`active-player-chip ${response === 'fold' ? 'folded-player-chip' : ''}`} key={participantId}><span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span>{player.name}<small>{player.id === activeRound.firstPlayerId ? 'abre' : activeRound.phase === 'dealing' ? checked ? '9 conferidas' : 'conferindo' : response === 'fold' ? 'saiu · sem débito' : activeRound.doubledByPlayerIds.includes(player.id) ? 'dobrou' : response === 'play' ? 'vai jogar' : 'decidindo'}</small></span>
            })}</div>
            <RoundControls room={room} playerId={playerId} isHost={isHost} busy={busy} onCardCheck={onCardCheck} onResponse={onResponse} onDouble={onDouble} onCancelVote={onCancelVote} onDialog={onDialog} />
          </section>}
          {!currentPlayer?.inGame && <div className="readonly-notice"><ShieldCheck size={15} /> Você saiu entre rodadas. Seu saldo das mãos anteriores permanece preservado; o resultado final aparecerá quando a partida terminar.</div>}
          <div className="summary-grid">
            <article className="summary-card balance-card"><div className="summary-card-top"><span>VALORES A RECEBER</span><span className="summary-icon coral-icon"><CircleDollarSign size={17} /></span></div><div className="balance-total">{money(creditorsTotal)}</div><div className="summary-foot"><span className="balance-dot" /> {room.entries.length} lançamentos manuais</div></article>
            <article className="summary-card"><div className="summary-card-top"><span>MÃOS CONCLUÍDAS</span><span className="summary-icon blue-icon"><Spade size={16} /></span></div><div className="summary-number">{String(room.rounds.length).padStart(2, '0')}</div><div className="summary-foot">Próximo a abrir <strong>{room.players.find((player) => player.id === room.nextOpenerId)?.name ?? '—'}</strong></div></article>
            <article className="summary-card"><div className="summary-card-top"><span>NA PARTIDA</span><span className="summary-icon green-icon"><UsersRound size={17} /></span></div><div className="summary-number">{String(players.length).padStart(2, '0')}</div><div className="summary-foot">lista muda entre rodadas</div></article>
          </div>
          {Math.abs(difference) > 0 && <div className="ledger-warning">Os lançamentos ainda diferem em {money(Math.abs(difference) / 100)}. Registre o crédito ou débito correspondente antes de encerrar.</div>}
          <div className="content-columns">
            <section className="panel transfers-panel"><div className="panel-heading"><div><span className="section-kicker">SALDOS PARCIAIS</span><h2>Acertos registrados</h2></div><button className="text-action" onClick={() => setTab('ledger')}>Ver todos <ArrowRight size={14} /></button></div>
              {players.map((player) => <div className="round-row" key={player.id}><span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span><div className="round-detail"><strong>{player.name}</strong><span>saldo na partida</span></div><span className={`round-value ${(balanceByPlayer.get(player.id) ?? 0) >= 0 ? 'positive' : 'negative'}`}>{money(balanceByPlayer.get(player.id) ?? 0)}</span></div>)}
              <div className="settlement-note"><span className="note-mark">i</span> Cada jogador perde o valor informado; o vencedor recebe o total dos demais.</div>
            </section>
            <section className="panel rounds-panel"><div className="panel-heading"><div><span className="section-kicker">ÚLTIMAS RODADAS</span><h2>Resultados</h2></div><button className="text-action" onClick={() => setTab('rounds')}>Ver todas <ArrowRight size={14} /></button></div>
              {room.rounds.slice(-4).reverse().map((round) => <div className="round-row" key={round.id}><span className="round-number">{String(round.number).padStart(2, '0')}</span><span className="round-symbol"><Heart size={15} fill="currentColor" /></span><div className="round-detail"><strong>{round.winnerName ? `${round.winnerName} venceu` : 'Resultado antigo não detalhado'}</strong><span>{money(round.value)} por jogador · {round.playerIds?.length ?? players.length} participantes <span className="bullet">·</span> {timeOnly(round.createdAt)}{round.correctedAt ? ' · corrigido' : ''}</span></div><span className="round-value">{round.winnerId ? `+${money(round.value * Math.max(0, (round.playerIds?.length ?? players.length) - 1))}` : '—'}</span></div>)}
              {!room.rounds.length && <p className="empty-copy">As rodadas aparecem aqui quando forem registradas.</p>}
            </section>
          </div>
          <div className="panel lobby-history activity-preview"><div className="panel-heading"><div><span className="section-kicker">HISTÓRICO SALVO</span><h2>Últimas ações</h2></div><button className="text-action" onClick={() => setTab('activity')}>Abrir log <ArrowRight size={14} /></button></div><ActivityList room={{ ...room, activity: room.activity.slice(-4) }} /></div>
        </>}
        {tab === 'overview' && room.status === 'finished' && <section className="panel report-panel"><div className="panel-heading"><div><span className="section-kicker">FECHAMENTO</span><h2>Quem paga e quem recebe</h2></div><span className="count-pill">Salvo no histórico</span></div><ResultView room={room} playerId={playerId} /></section>}
        {tab === 'rounds' && <section className="panel list-panel"><div className="panel-heading"><div><span className="section-kicker">QUEM JOGOU, VALORES E QUEM BATEU</span><h2>{room.rounds.length} {room.rounds.length === 1 ? 'rodada' : 'rodadas'}</h2></div></div>{activeRound && <p className="waiting-host active-round-inline"><Clock3 size={15} /> Mão {activeRound.number} em andamento.</p>}<RoundsHistory room={room} onCorrect={isHost && room.status !== 'waiting' ? (roundId) => onDialog('correct-round', roundId) : undefined} /><p className="settlement-note"><span className="note-mark">i</span> Só quem jogou a rodada entra no saldo. Corrigir o vencedor exige motivo e fica no histórico.</p></section>}
        {tab === 'ledger' && <section className="panel ledger-panel"><div className="panel-heading"><div><span className="section-kicker">LIVRO-CAIXA MANUAL</span><h2>{room.entries.length} lançamentos</h2></div></div><div className="ledger-table-head"><span>JOGADOR</span><span>DESCRIÇÃO</span><span>HORÁRIO</span><span>VALOR</span></div>{[...room.entries].reverse().map((entry) => <div className="ledger-row" key={entry.id}><div className="ledger-player"><span className="avatar avatar-blue">{initials(entry.playerName)}</span><strong>{entry.playerName}</strong></div><span className="ledger-description">{entry.description}</span><span className="ledger-time">{timeOnly(entry.createdAt)}</span><span className={`ledger-amount ${entry.amount > 0 ? 'positive' : 'negative'}`}>{entry.amount > 0 ? '+' : '−'}{money(Math.abs(entry.amount))}</span></div>)}{!room.entries.length && <p className="empty-copy">Nenhum acerto lançado.</p>}</section>}
        {tab === 'activity' && <section className="panel activity-panel"><div className="panel-heading"><div><span className="section-kicker">REGISTRO SALVO NO CELULAR</span><h2>Histórico completo</h2></div><span className="count-pill">{room.activity.length} eventos</span></div><ActivityList room={room} /></section>}
        <div className="room-actions">
          <button className="button button-secondary" onClick={onExit}><LogOut size={15} /> {room.status === 'finished' ? 'Ver resultado e sair' : isHost ? 'Encerrar e sair' : 'Sair da mesa'}</button>
          {room.status !== 'waiting' && isHost && !activeRound && room.rounds.length > 0 && <button className="text-action" onClick={() => onDialog('undo')}><Undo2 size={15} /> Desfazer última rodada</button>}
          {isHost && <button className="text-action" onClick={() => onDialog('rename')}><PencilLine size={15} /> Renomear jogador</button>}
          {room.status === 'waiting' && isHost && <button className="button button-primary" disabled={players.length < 2 || busy} onClick={() => void onStart()}><Spade size={16} /> Iniciar partida</button>}
        </div>
        <footer className="page-footer"><span><span className="live-dot" /> {statusText}</span><span>{room.status === 'waiting' ? 'A lista fecha ao iniciar.' : `Início: ${localDate(room.startedAt)}${room.finishedAt ? ` · Fim: ${localDate(room.finishedAt)}` : ''}`}</span></footer>
      </section>
    </div>
    <nav className="mobile-nav" aria-label="Navegação principal">
      <button className={tab === 'overview' ? 'selected' : ''} onClick={() => setTab('overview')}><CircleDollarSign size={19} /><span>Resumo</span></button>
      <button className={tab === 'rounds' ? 'selected' : ''} onClick={() => setTab('rounds')}><Spade size={19} /><span>Rodadas</span></button>
      <button className={tab === 'ledger' ? 'selected' : ''} onClick={() => setTab('ledger')}><ClipboardList size={19} /><span>Acertos</span></button>
      <button className={tab === 'activity' ? 'selected' : ''} onClick={() => setTab('activity')}><History size={19} /><span>Log</span></button>
    </nav>
  </main>
}

function SoloRoundForm({ room, onSubmit }: { room: Room; onSubmit: (data: FormData) => void }) {
  const active = room.players.filter((player) => player.inGame)
  const [openerId, setOpenerId] = useState(active.some((player) => player.id === room.nextOpenerId) ? room.nextOpenerId! : active[0]?.id ?? '')
  const settings = useSettings()
  const [value, setValue] = useState(settings.defaultValue ? String(settings.defaultValue) : '')
  const [playing, setPlaying] = useState<string[]>(active.map((player) => player.id))
  const [doubled, setDoubled] = useState<string[]>([])
  const toggle = (list: string[], id: string) => (list.includes(id) ? list.filter((item) => item !== id) : [...list, id])
  const players = playing.includes(openerId) ? playing : [...playing, openerId]
  const validDoubles = doubled.filter((id) => players.includes(id) && id !== openerId)
  const base = Number(value)
  const finalValue = Number.isFinite(base) && base > 0 ? base * 2 ** validDoubles.length : 0

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    onSubmit(new FormData(event.currentTarget))
  }

  return <form className="form-stack" onSubmit={submit}>
    <label>Quem abriu (anunciou o valor)?<select id="solo-opener" name="openerId" value={openerId} onChange={(event) => setOpenerId(event.target.value)}>{active.map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}</select></label>
    <label>Valor anunciado por pessoa<div className="currency-input"><span>R$</span><input id="solo-value" name="value" type="number" inputMode="decimal" min="0.01" step="0.01" placeholder="10,00" value={value} onChange={(event) => setValue(event.target.value)} required /></div></label>
    <fieldset className="participant-fieldset"><legend>Quem jogou esta mão?</legend>{active.map((player) => <label className="participant-option" key={player.id}><input type="checkbox" name="playerIds" value={player.id} checked={players.includes(player.id)} disabled={player.id === openerId} onChange={() => setPlaying(toggle(playing, player.id))} /><span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span><span>{player.name}{player.id === openerId ? ' (abriu)' : ''}</span></label>)}</fieldset>
    <fieldset className="participant-fieldset"><legend>Quem dobrou? (quem abriu não dobra)</legend>{active.filter((player) => players.includes(player.id) && player.id !== openerId).map((player) => <label className="participant-option" key={player.id}><input type="checkbox" name="doubledIds" value={player.id} checked={doubled.includes(player.id)} onChange={() => setDoubled(toggle(doubled, player.id))} /><span className={`avatar avatar-${playerColor(player.id)}`}>{initials(player.name)}</span><span>{player.name}</span></label>)}</fieldset>
    <label>Quem bateu?<select id="solo-winner" name="winnerId" required defaultValue=""><option value="" disabled>Selecione quem bateu</option>{active.filter((player) => players.includes(player.id)).map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}</select></label>
    {finalValue > 0 && <p className="correction-current">Valendo <strong>{money(finalValue)}</strong> por jogador. Quem bateu recebe <strong>{money(finalValue * (players.length - 1))}</strong>.</p>}
    <button className="button button-primary full-button" type="submit"><Check size={16} /> Salvar rodada</button>
  </form>
}

function RoomDialog({ room, dialog, roundId, isHost, onClose, onSubmit }: {
  room: Room
  isHost: boolean
  dialog: Exclude<Dialog, null>
  roundId?: string
  onClose: () => void
  onSubmit: (dialog: Exclude<Dialog, null>, data: FormData) => Promise<void>
}) {
  const settings = useSettings()
  const lastRound = room.rounds.at(-1)
  const correctedRound = room.rounds.find((round) => round.id === roundId)
  const playingParticipants = room.players.filter((player) => room.activeRound?.playingPlayerIds.includes(player.id))
  const currentPlayers = room.players.filter((player) => player.inGame)

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    void onSubmit(dialog, new FormData(event.currentTarget))
  }

  const title = dialog === 'solo-round'
    ? `Registrar rodada ${room.roundNumber + 1}`
    : dialog === 'add-player'
      ? 'Adicionar jogador'
    : dialog === 'undo'
      ? `Desfazer a rodada ${lastRound?.number ?? ''}?`
    : dialog === 'rename'
      ? 'Renomear jogador'
    : dialog === 'exit'
      ? room.status === 'finished' ? 'Sair da mesa' : isHost ? 'Encerrar a mesa?' : 'Sair da mesa?'
    : dialog === 'announce-round'
      ? 'Anunciar o valor'
    : dialog === 'round-result'
      ? 'Registrar vencedor'
      : dialog === 'correct-round'
        ? `Corrigir rodada ${correctedRound?.number ?? ''}`
        : 'Lançar acerto manual'

  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="dialog-title">
      <div className="modal-heading"><div><span className="section-kicker">{room.name.toUpperCase()}</span><h2 id="dialog-title">{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Fechar"><X size={19} /></button></div>
      {dialog === 'solo-round' && <SoloRoundForm room={room} onSubmit={(data) => void onSubmit(dialog, data)} />}
      {dialog === 'add-player' && <form className="form-stack" onSubmit={submit}>
        <label>Nome do jogador<input id="add-player-name" name="name" maxLength={50} placeholder="Ex.: Dudu" required autoFocus /></label>
        <button className="button button-primary full-button" type="submit"><Plus size={16} /> Colocar na mesa</button>
      </form>}
      {dialog === 'undo' && lastRound && <form className="form-stack" onSubmit={submit}>
        <p className="correction-current">Rodada {lastRound.number}: <strong>{lastRound.winnerName ?? '?'}</strong> bateu valendo <strong>{money(lastRound.value)}</strong> por jogador. Ela será apagada e os saldos voltam a ser como antes dela. Fica anotado no histórico.</p>
        <button className="button button-primary full-button" type="submit"><Undo2 size={16} /> Desfazer rodada {lastRound.number}</button>
        <button className="button button-secondary full-button" type="button" onClick={onClose}>Manter</button>
      </form>}
      {dialog === 'rename' && <form className="form-stack" onSubmit={submit}>
        <label>Jogador<select id="rename-player" name="playerId" required defaultValue="">{[<option value="" disabled key="">Selecione</option>, ...room.players.map((player) => <option value={player.id} key={player.id}>{player.name}{player.inGame ? '' : ' (saiu)'}</option>)]}</select></label>
        <label>Novo nome<input id="rename-name" name="name" maxLength={50} required /></label>
        <p className="form-hint">O nome muda em todas as rodadas desta mesa. Fica anotado no histórico.</p>
        <button className="button button-primary full-button" type="submit"><PencilLine size={16} /> Renomear</button>
      </form>}
      {dialog === 'exit' && <form className="form-stack" onSubmit={submit}>
        <p className="correction-current">{room.status === 'finished'
          ? 'A partida já terminou. Você vai ver o resultado e depois voltar ao início.'
          : isHost
            ? 'A mesa será encerrada para todos e o resultado fica salvo no histórico. Antes de voltar ao início, você vê o resultado completo.'
            : 'A mesa se encerra para você. Seu saldo até aqui fica salvo e os outros continuam jogando. Antes de voltar ao início, você vê o resultado.'}</p>
        <button className="button button-primary full-button" type="submit"><LogOut size={16} /> {room.status === 'finished' ? 'Ver resultado' : isHost ? 'Encerrar e ver resultado' : 'Sair e ver resultado'}</button>
        <button className="button button-secondary full-button" type="button" onClick={onClose}>Continuar na mesa</button>
      </form>}
      {dialog === 'announce-round' && <form className="form-stack" onSubmit={submit}>
        <p className="correction-current">Você abre esta mão. Depois do anúncio você fica na mão e não pode dobrar.</p>
        <label>Qual é o valor inicial por pessoa?<div className="currency-input"><span>R$</span><input name="value" type="number" inputMode="decimal" min="0.01" step="0.01" placeholder="10,00" defaultValue={settings.defaultValue ?? undefined} required autoFocus /></div></label>
        <p className="form-hint">Depois do anúncio, cada um dos outros confirma, sai sem débito ou dobra o valor uma vez.</p>
        <button className="button button-primary full-button" type="submit"><CircleDollarSign size={16} /> Anunciar valor</button>
      </form>}
      {dialog === 'round-result' && <form className="form-stack" onSubmit={submit}>
        <p className="correction-current">Mão {room.activeRound?.number} · {money(room.activeRound?.value ?? 0)} por pessoa · {playingParticipants.length} jogadores</p>
        <label>Quem bateu?<select name="winnerId" required defaultValue="" autoFocus><option value="" disabled>Selecione quem bateu</option>{playingParticipants.map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}</select></label>
        <p className="form-hint">Quem saiu antes do jogo começar e quem não recebeu cartas não terá saldo alterado.</p>
        <button className="button button-primary full-button" type="submit"><Check size={16} /> Salvar resultado</button>
      </form>}
      {dialog === 'correct-round' && <form className="form-stack" onSubmit={submit}>
        <p className="correction-current">Vencedor registrado: <strong>{correctedRound?.winnerName ?? 'não informado'}</strong></p>
        <label>Quem venceu de verdade?<select name="winnerId" required defaultValue=""><option value="" disabled>Selecione o vencedor correto</option>{room.players.filter((player) => (correctedRound?.playerIds?.includes(player.id) ?? player.inGame) && player.id !== correctedRound?.winnerId).map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}</select></label>
        <label>O que aconteceu?<input name="reason" maxLength={240} placeholder="Ex.: anotamos o vencedor errado" required /></label>
        <p className="form-hint">Os saldos serão recalculados e a correção ficará registrada no histórico.</p>
        <button className="button button-primary full-button" type="submit"><Check size={16} /> Corrigir resultado</button>
      </form>}
      {dialog === 'entry' && <form className="form-stack" onSubmit={submit}>
        <label>Jogador<select name="playerId" required>{currentPlayers.map((player) => <option value={player.id} key={player.id}>{player.name}</option>)}</select></label>
        <label>Tipo<select name="direction"><option value="debit">Débito: jogador paga</option><option value="credit">Crédito: jogador recebe</option></select></label>
        <label>Valor<div className="currency-input"><span>R$</span><input name="amount" type="number" min="0.01" step="0.01" inputMode="decimal" placeholder="0,00" required /></div></label>
        <label>Descrição<input name="description" placeholder="Ex.: acerto combinado" maxLength={160} /></label>
        <p className="form-hint">O lançamento é manual e ficará registrado no histórico.</p>
        <button className="button button-primary full-button" type="submit"><Check size={16} /> Salvar lançamento</button>
      </form>}
    </section>
  </div>
}

function ConnectionScreen({ reason }: { reason: 'no-claude' | 'signed-out' }) {
  return <main className="gate-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel">
      <span className="section-kicker">ACESSO</span>
      <h1>Entre no Claude para jogar</h1>
      <p className="gate-copy">{reason === 'signed-out'
        ? 'As mesas ficam salvas nesta página do Claude. Faça login na sua conta (a grátis serve) e peça para quem criou a página te convidar pelo e-mail como Editor.'
        : 'Esta versão do Pif da Mesa funciona aberta pelo Claude. Abra o link da página no app ou no site do Claude.'}</p>
    </section>
  </main>
}

function App() {
  const [platform, setPlatform] = useState<Platform | null>(null)
  const [connection, setConnection] = useState<'connecting' | 'ready' | 'no-claude' | 'signed-out'>('connecting')
  const [roomCode, setRoomCode] = useState(getRoomCodeFromUrl)
  const [room, setRoom] = useState<Room | null>(null)
  const [roomList, setRoomList] = useState<RoomSummary[]>([])
  const [viewAsPlayerId, setViewAsPlayerId] = useState('')
  const [loading, setLoading] = useState(Boolean(getRoomCodeFromUrl()))
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [tab, setTab] = useState<Tab>('overview')
  const [dialog, setDialog] = useState<Dialog>(null)
  const [correctingRoundId, setCorrectingRoundId] = useState<string | undefined>()
  const [homeError, setHomeError] = useState('')
  const [showHistory, setShowHistory] = useState(false)
  const [showResult, setShowResult] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [connectionIssue, setConnectionIssue] = useState('')
  const [showTraining, setShowTraining] = useState(false)
  const [celebration, setCelebration] = useState<{ key: string; winner: string; amount: number; round: number } | null>(null)
  const seenRounds = useRef<{ code: string; count: number } | null>(null)

  useEffect(() => { applyLook() }, [])

  // Abrir um link de mesa (#CODIGO) com o app já aberto também leva para a mesa.
  useEffect(() => {
    const onHash = () => {
      const code = getRoomCodeFromUrl()
      if (code && code !== roomCode) {
        setHomeError('')
        setLoading(true)
        setRoom(null)
        setViewAsPlayerId('')
        setShowHistory(false)
        setShowSettings(false)
        setShowResult(false)
        setRoomCode(code)
      }
    }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [roomCode])

  // Comemoração para todos quando uma rodada nova é registrada.
  const roundsCount = room?.rounds.length ?? 0
  useEffect(() => {
    if (!room) {
      seenRounds.current = null
      return
    }
    const previous = seenRounds.current
    seenRounds.current = { code: room.code, count: roundsCount }
    if (!previous || previous.code !== room.code || roundsCount <= previous.count) return
    const last = room.rounds[roundsCount - 1]
    if (!last?.winnerName) return
    setCelebration({ key: last.id, winner: last.winnerName, amount: last.value * Math.max(0, (last.playerIds?.length ?? 1) - 1), round: last.number })
    const timer = window.setTimeout(() => setCelebration(null), 3200)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room?.code, roundsCount])

  useEffect(() => {
    let active = true
    void connect().then((result) => {
      if (!active) return
      if (result.ok) {
        setPlatform(result.platform)
        setConnection('ready')
      } else {
        setConnection(result.reason)
      }
    })
    return () => { active = false }
  }, [])

  // A lista de mesas só é consultada fora de uma mesa (tela inicial, histórico, configurações).
  useEffect(() => {
    if (!platform || roomCode) return
    return subscribeRoomList(platform, setRoomList)
  }, [platform, roomCode])

  useEffect(() => {
    if (!platform || !roomCode) return
    let first = true
    const unsubscribe = subscribeRoom(platform, roomCode, (nextRoom) => {
      if (first) {
        first = false
        setLoading(false)
        if (!nextRoom) {
          setHomeError('Não encontramos essa mesa. Confira o código do convite.')
          setRoomCode('')
          setUrlCode('')
          return
        }
      }
      if (nextRoom) setRoom(nextRoom)
    }, (error) => {
      setLoading(false)
      setConnectionIssue(error)
    })
    return () => { unsubscribe(); setConnectionIssue('') }
  }, [platform, roomCode])

  function openRoom(code: string) {
    const normalized = code.trim().toUpperCase()
    if (!normalized) return
    setHomeError('')
    setLoading(true)
    setRoom(null)
    setViewAsPlayerId('')
    setShowHistory(false)
    setShowResult(false)
    setRoomCode(normalized)
    setUrlCode(normalized)
  }
  async function createNewRoom(name: string, playerName: string, soloNames?: string[]) {
    if (!platform) return
    setBusy(true)
    setHomeError('')
    try {
      const created = await createRoom(platform, name, playerName, soloNames)
      setRoom(created)
      setRoomCode(created.code)
      setUrlCode(created.code)
    } catch (error) {
      setHomeError(error instanceof Error ? error.message : 'Não foi possível criar a sala.')
    } finally { setBusy(false) }
  }
  async function mutate(action: Action): Promise<boolean> {
    if (!room || !platform) return false
    setBusy(true)
    setMessage('')
    try {
      setRoom(await mutateRoom(platform, room.code, action))
      return true
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Não foi possível atualizar a mesa.')
      return false
    } finally { setBusy(false) }
  }

  const ownPlayer = room && platform ? playerForUser(room, platform.userId) : undefined
  const currentPlayerId = ownPlayer?.id ?? viewAsPlayerId

  const isHost = Boolean(platform && room && room.hostUserId === platform.userId)

  // Aviso de vez (opcional, ligado nas Configurações deste celular).
  const hand = room?.activeRound
  const myTurn = Boolean(hand && currentPlayerId && (
    (hand.phase === 'announcing' && hand.firstPlayerId === currentPlayerId)
    || (hand.phase === 'responding' && hand.responses?.[currentPlayerId] === 'pending')
  ))
  const turnKey = myTurn && hand ? `${room?.code}-${hand.number}-${hand.phase}-${hand.value}` : ''
  useEffect(() => {
    if (turnKey && getTurnAlerts()) turnAlert()
  }, [turnKey])

  /** "Sair": jogador sai da mesa; anfitrião encerra para todos. Antes do início, mostra o resultado. */
  function exitRoom() {
    if (!room) return
    const me = room.players.find((player) => player.id === currentPlayerId)
    if (room.status === 'finished' || !me || !me.inGame) {
      setShowResult(true)
      return
    }
    if (room.activeRound) {
      setMessage('Termine ou cancele a rodada atual antes de sair.')
      return
    }
    setDialog('exit')
  }
  async function confirmExit() {
    if (!room) return
    let ok = true
    if (room.status !== 'finished') {
      if (isHost) ok = await mutate({ type: 'finish' })
      else ok = await mutate({ type: 'leave', playerId: currentPlayerId })
    }
    setDialog(null)
    if (ok) setShowResult(true)
  }
  async function submitDialog(which: Exclude<Dialog, null>, form: FormData) {
    if (!room) return
    if (which === 'exit') {
      await confirmExit()
      return
    }
    let saved = false
    if (which === 'solo-round') {
      saved = await mutate({
        type: 'solo-round',
        openerId: String(form.get('openerId') ?? ''),
        value: Number(form.get('value')),
        playerIds: [...form.getAll('playerIds').map(String), String(form.get('openerId') ?? '')],
        doubledIds: form.getAll('doubledIds').map(String),
        winnerId: String(form.get('winnerId') ?? ''),
      })
    } else if (which === 'undo') {
      saved = await mutate({ type: 'undo-round' })
    } else if (which === 'rename') {
      saved = await mutate({ type: 'rename-player', playerId: String(form.get('playerId') ?? ''), name: String(form.get('name') ?? '') })
    } else if (which === 'add-player') {
      saved = await mutate({ type: 'add-player', name: String(form.get('name') ?? '') })
    } else if (which === 'announce-round') {
      saved = await mutate({ type: 'announce', playerId: currentPlayerId, value: Number(form.get('value')) })
    } else if (which === 'round-result') {
      saved = await mutate({ type: 'round-result', winnerId: String(form.get('winnerId') ?? '') })
    } else if (which === 'correct-round' && correctingRoundId) {
      saved = await mutate({ type: 'correct', roundId: correctingRoundId, winnerId: String(form.get('winnerId') ?? ''), reason: String(form.get('reason') ?? '').trim() })
    } else {
      const amount = Number(form.get('amount')) * (form.get('direction') === 'debit' ? -1 : 1)
      saved = await mutate({ type: 'entry', playerId: String(form.get('playerId') ?? ''), amount, description: String(form.get('description') ?? '').trim() || 'Acerto manual' })
    }
    if (saved) {
      setDialog(null)
      setCorrectingRoundId(undefined)
    }
  }
  async function shareRoom() {
    if (!room) return
    const base = await networkBase()
    if (!base) {
      setMessage('Ligue o roteador do celular (hotspot) ou conecte num Wi-Fi para gerar o link dos amigos.')
      return
    }
    const link = `${base}/#${room.code}`
    const ok = await copyText(`Bora jogar Pif! Entra no Wi-Fi/roteador do anfitrião e abre ${link}`)
    setMessage(ok ? `Convite copiado: ${link}` : `Link da mesa: ${link}`)
  }
  function leaveRoomView() {
    setShowResult(false)
    setRoomCode('')
    setRoom(null)
    setViewAsPlayerId('')
    setTab('overview')
    setMessage('')
    setUrlCode('')
  }
  if (connection === 'no-claude' || connection === 'signed-out') return <ConnectionScreen reason={connection} />
  if (connection === 'connecting' || (loading && !room)) return <main className="gate-shell"><p>{connection === 'connecting' ? 'Conectando à mesa...' : 'Abrindo a sala...'}</p></main>
  if (showTraining && !roomCode) return <TrainingScreen onBack={() => setShowTraining(false)} />
  if (showSettings && !roomCode) return <SettingsScreen summaries={roomList} isHostDevice={isHostDevice} onBack={() => setShowSettings(false)} />
  if (showHistory && !roomCode) return <HistoryScreen summaries={roomList} canDelete={isHostDevice} onBack={() => setShowHistory(false)} onOpen={openRoom} />
  if (!roomCode || !room) return <HomeScreen onCreate={createNewRoom} onOpen={openRoom} onHistory={() => setShowHistory(true)} onSettings={() => setShowSettings(true)} onTraining={() => setShowTraining(true)} message={homeError} busy={busy} rooms={roomList} />
  if (showResult) return <main className="gate-shell result-shell">
    <header className="gate-brand"><span className="brand-mark"><Spade size={20} fill="currentColor" /></span><span>Pif<span className="brand-light"> da mesa</span></span></header>
    <section className="gate-panel result-panel">
      <span className="section-kicker">{room.status === 'finished' ? 'MESA ENCERRADA' : 'VOCÊ SAIU DA MESA'}</span>
      <h1>{room.name}</h1>
      <p className="gate-copy">{room.status === 'finished' ? `Encerrada ${localDate(room.finishedAt)} · ${room.rounds.length} rodadas` : `${room.rounds.length} rodadas até agora. A mesa continua para quem ficou.`}</p>
      <ResultView room={room} playerId={currentPlayerId} />
      <button type="button" className="button button-primary full-button" onClick={leaveRoomView}><ArrowRight size={16} /> Voltar ao início</button>
    </section>
  </main>
  if (!currentPlayerId) return <JoinScreen room={room} code={roomCode} onJoin={async (name) => {
    const existing = room.players.find((item) => item.inGame && item.name.trim().toLocaleLowerCase('pt-BR') === name.trim().toLocaleLowerCase('pt-BR'))
    await mutate(existing ? { type: 'claim', playerId: existing.id } : { type: 'join', name })
  }} onResume={(name) => {
    const player = room.players.find((item) => item.name.trim().toLocaleLowerCase('pt-BR') === name.trim().toLocaleLowerCase('pt-BR'))
    if (player) {
      setViewAsPlayerId(player.id)
      setMessage('')
      if (room.status !== 'finished') void mutate({ type: 'claim', playerId: player.id })
    } else {
      setMessage('Esse nome não está registrado na partida. Confira como foi escrito ou fale com o anfitrião.')
    }
  }} message={message} busy={busy} />
  return <>
    <RoomDashboard room={room} playerId={currentPlayerId} isHost={isHost} tab={tab} setTab={setTab} message={message} busy={busy} onShare={shareRoom} onExit={exitRoom} onNewRound={async () => { await mutate({ type: 'round-start' }) }} onStart={async () => { await mutate({ type: 'start' }) }} onCancelVote={async () => { await mutate({ type: 'cancel-vote', playerId: currentPlayerId }) }} onCardCheck={async (count) => { await mutate({ type: 'cards-check', playerId: currentPlayerId, count }) }} onResponse={async (choice) => { await mutate({ type: 'response', playerId: currentPlayerId, choice }) }} onDouble={async () => { await mutate({ type: 'double', playerId: currentPlayerId }) }} onDialog={(nextDialog, roundId) => { setCorrectingRoundId(roundId); setDialog(nextDialog) }} />
    {busy && <div className="busy-indicator" role="status"><span /> Salvando...</div>}
    {connectionIssue && <div className="connection-banner" role="alert"><span className="connection-dot" /> {connectionIssue} Tentando reconectar...</div>}
    {celebration && <div className="celebration" key={celebration.key} role="status" onClick={() => setCelebration(null)}>
      <div className="celebration-card">
        <span className="celebration-cards" aria-hidden="true">♠ ♥ ♣ ♦</span>
        <strong>{celebration.winner} bateu!</strong>
        <span className="celebration-amount">+{money(celebration.amount)}</span>
        <small>Rodada {celebration.round}</small>
      </div>
    </div>}
    {dialog && <RoomDialog room={room} isHost={isHost} dialog={dialog} roundId={correctingRoundId} onClose={() => { setDialog(null); setCorrectingRoundId(undefined) }} onSubmit={submitDialog} />}
  </>
}

export default App
